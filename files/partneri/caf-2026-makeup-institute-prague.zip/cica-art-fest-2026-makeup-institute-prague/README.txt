ČÍČA ART FEST 2026 — FOTKY PRO PARTNERA: MAKE UP INSTITUTE PRAGUE
================================================================

Fotografie z prvního ročníku Číča Art Festu (28. 8. 2026, CO.LABS Brno),
na kterých je vidět vaše účast. Volně je používejte na webu, sociálních
sítích i v tištěných materiálech.

Při zveřejnění prosíme uvádět kredit:
Foto: Adelice (Instagram @adelice_foto)

Budeme rádi, když k fotkám označíte @cicaartfest a @podrazdena_cica.

Kontakt: David Koutný, jsem@podrazdenacica.cz, +420 732 227 989
