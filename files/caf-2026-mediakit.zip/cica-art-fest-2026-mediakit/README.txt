ČÍČA ART FEST 2026 — MEDIAKIT
=============================

První ročník festivalu Číča Art Fest proběhl 28. srpna 2026
v areálu CO.LABS v Brně. Pořádá brand Podrážděná číča.

OBSAH BALÍČKU
- fotky/  26 oficiálních fotografií z festivalu
- loga/   logo Číča Art Festu a logo brandu Podrážděná číča

PODMÍNKY POUŽITÍ
Fotografie a loga jsou volné k redakčnímu použití v souvislosti
s festivalem Číča Art Fest a brandem Podrážděná číča.

Při publikaci fotografií prosíme uvádět kredit:
Foto: Adelice (Instagram @adelice_foto)

KONTAKT PRO MÉDIA
David Koutný, pořadatel festivalu
E-mail: jsem@podrazdenacica.cz
Telefon: +420 732 227 989
Web: https://www.podrazdenacica.cz/cica-art-fest/media
Instagram: @cicaartfest, @podrazdena_cica
